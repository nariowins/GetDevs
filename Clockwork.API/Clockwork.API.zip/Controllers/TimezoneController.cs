﻿using System;
using Microsoft.AspNetCore.Mvc;
using Clockwork.API.Models;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Clockwork.API.Controllers
{
    [Route("api/[controller]")]
    public class TimeZoneController : Controller
    {
        // GET api/currenttime
        [HttpGet]
        public IActionResult Get()
        {
            var path = $"{AppDomain.CurrentDomain.BaseDirectory}\\TimeZone.json";
            var jsonText = System.IO.File.ReadAllText(path);
            var jsonTimeZone = JsonConvert.DeserializeObject<List<TimeZoneModel>>(jsonText);

            return Ok(jsonTimeZone);
        }
    }
}
