﻿using Clockwork.API.Models;
using Clockwork.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace Clockwork.API.Controllers
{
    [Route("api/[controller]")]
    public class CurrentTimeController : Controller
    {
        // GET api/currenttime
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var utcTime = DateTime.UtcNow;
                var serverTime = DateTime.Now;
                var ip = HttpContext.Connection.RemoteIpAddress.ToString();

                var returnVal = new CurrentTimeQuery
                {
                    UTCTime = utcTime,
                    ClientIp = ip,
                    Time = serverTime
                };

                using (var db = new ClockworkContext())
                {
                    db.CurrentTimeQueries.Add(returnVal);
                    db.SaveChanges();
                }

                return Ok(returnVal);
            }
            catch (Exception e)
            {
               //Logger here
                return BadRequest(e);
            }
        }

        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                using (var db = new ClockworkContext())
                {
                    var currentTimeList = db.CurrentTimeQueries.ToList();
                    return Ok(currentTimeList);
                }
            }
            catch (Exception e)
            {
               //Logger here
                return BadRequest(e);
            }      
        }
    }
}
